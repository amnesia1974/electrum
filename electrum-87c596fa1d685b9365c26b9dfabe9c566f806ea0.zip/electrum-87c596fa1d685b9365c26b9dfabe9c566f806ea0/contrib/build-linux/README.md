Source tarballs
===============

1. Build locale files

    ```
    contrib/make_locale
    ```

2. Prepare python dependencies used by Electrum.

    ```
    contrib/make_packages
    ```

3. Create source tarball.

    ```
    contrib/make_tgz
    ```
