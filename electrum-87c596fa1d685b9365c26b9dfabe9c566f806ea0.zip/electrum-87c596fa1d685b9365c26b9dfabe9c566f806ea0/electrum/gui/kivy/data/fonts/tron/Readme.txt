TR2N v1.3

ABOUT THE FONT:
A font based upon the poster text for TRON LEGACY.

The font is different from the pre-existing TRON font currently on the web.  Similar in minor aspects but different in most.  Style based upon text from different region posters.

UPDATE HISTORY:
3/7/11 - Adjusted the letter B (both lowercase and uppercase), capped off the ends of T, P and R, added a few more punctuation marks, as well as added the TR and TP ligature to allow for the solid bar connect as in the poster art.

1/22/11 - Made minor corrections to all previous letters and punctuation.  Corrected issue with number 8's top filling in.

ABOUT THE AUTHOR:
Jeff Bell has produced fonts before, but this is the first one in over 10 years.  His original 3 fonts were under the name DJ-JOHNNYRKA and include "CASPER", "BEVERLY HILLS COP", "THE GODFATHER" and "FIDDUMS FAMILY".

For more information on Jeff Bell and his work can be found online:

www.randombell.com
www.damovieman.deviantart.com
http://www.imdb.com/name/nm3983081/
http://www.vimeo.com/user4004969/videos